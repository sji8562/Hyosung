<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<title></title>
	<style type="text/css">
		*{
			margin:0 auto;
			padding: 0;
		}
		header{
			width: 100%;
			height: 150px;
			background-color: yellow;
		}
		.logo{
			width: 148px;
			height: 148px;
			border:1px solid black;
			float: left;
		}
		nav{
			width: 850px;
			height: 150px;
			background-color: green;
			float: left;
		}
		section{
			width: 1000px;
			min-height: 500px;
			background-color: gray;
		}

		footer{
			width: 100%;
			height: 100px;
			background-color: pink;
		}
	</style>
</head>
<body>
	<header>
		<div style="width: 1000px;">
			<div class="logo">로고</div>
			<nav>메뉴</nav>
		</div>
		
	</header>
	<section>
		
	</section>
	<footer>
		
	</footer>
</body>
</html>