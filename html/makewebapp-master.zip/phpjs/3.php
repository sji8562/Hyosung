<!DOCTYPE html>
<html>
<head>
     <meta charset="utf-8">
</head>
<body>
  <script charset="utf-8">
    document.write("hello world");
  </script>
  <?php

  ?>
</body>
</html>
