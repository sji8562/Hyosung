<?php
$config = array(
  "host"=>"localhost",
  "duser"=>"root",
  "dpw"=>"111111",
  "dname"=>"opentutorials"
);
?>
